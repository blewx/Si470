Mauritius 2018 TUS:

Major divisions 1,2,3,4,5,6,7,8,9 were given in hrs/day

Total (male and female average) given for 1-6. 
To get total for subcategories in 7 and 8, used gender ratio from the survey: 

46% males
54% females

total_hrs = male_hrs*0.46 + female_hrs*0.54


