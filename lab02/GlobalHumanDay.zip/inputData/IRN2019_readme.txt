All the Iran TUSs:

1398-1399 (2019-2020) full report:

- note: the year 1399 is March 20, 2020 - March 20, 2021
- autumn 1398 = autumn 2019
- winter 1398 = winter 2019-20
- spring 1399 = spring 2020
- summer 1399 = summer 2020

- data on p.3 (total avg) and p.4 (male, female) out of p.22
- already given in hrs
- activity classification follows ICATUS 2016
- to get hours_per_day, gave equal weight to all 4 seasons (added total_seasons_times and divided by 4)



