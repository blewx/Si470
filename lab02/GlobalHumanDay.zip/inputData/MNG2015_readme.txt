Mongolia 2015 TUS:

Only female and male hrs provided
-> to find total hrs, used gender ratio from survey: https://catalog.ihsn.org/catalog/8344/data-dictionary/F2?file_name=Population

51.5% female
48.5% male

"Paid employment" subdivisions split into urban/rural for females and males
-> to find female_total and male_total, used urban/rural ratio from web: https://data.worldbank.org/indicator/SP.URB.TOTL.IN.ZS?locations=MN

68.23% urban
31.77% rural

The "paid employment" subdivision called "other/unknown" was not on the infographic
-> calculated by: hrs_other/unknown = hrs_paid_employment - hrs_subdivisions