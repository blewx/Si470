Tunisia TUS:
- 2005-2006
- nationally representative
- one csv called "_gender split" and another csv called "_total"
(since "total" vs "female/male" time use in PDF uses slightly different category names)
- tier1 and tier2 are the same in "_gender split", but different in "_total"

Time given in hrs:min -> converted to hrs (*24)

For "total": combined graphiques 2, 31, 42, 5, and 6
For "female": used "female total" column on p.10 (tableau 1)
For "male": used "male total" column on p.10 (tableau 1)

Note: if I was unsure of the correct English translation, I also included the original French activity in parentheses 

