Costa Rica 2017 TUS:

Used "tiempo social promedio" given in hrs:min per week for females and males separately
-> converted hrs:min per week -> hrs per week (*24) -> hrs/day (/7)
-> then used gender ratio given in survey to find total average
 
49.735% females (2,028,366/4,078,350)
50.265% males (2,049,984/4,078,350)




