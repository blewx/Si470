Algeria TUS:

- took data from tab.25 (p.40 of 90)
- note: "other housework" = such as washing clothes, ironing, dishes (p.24)

- to find total_total, used urban/rural ratio:
-> According to survey (p.8 of 90) * used this one *
	Number of households:
	Urban: 6091/9015 = 0.67565		
	Rural: 2924/9015 = 0.32435
	*caution: this is #households that are urban or rural, not #people